<?php

wa('contacts'); // !!! probably should inherit the other way around?..

/** Contact photo upload, step one: upload and save a full-sized image
  * to allow user to crop later. */
class webasystProfileTmpimageController extends contactsPhotoTmpimageController
{
    // Nothing to override!
}
