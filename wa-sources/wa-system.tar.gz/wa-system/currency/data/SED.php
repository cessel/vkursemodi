<?php

return array(
    'code' => 'SED',
    'sign' => 'د.إ',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'United Arab Emirates dirham',
    'name' => array(
        array('dirham', 'dirhams'),
    ),
    'frac_name' => array(
        'fils',
    )
);