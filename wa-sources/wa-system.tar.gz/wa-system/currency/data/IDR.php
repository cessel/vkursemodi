<?php

return array(
    'code' => 'IDR',
    'sign' => 'Rp',
    'sign_position' => 0,
    'sign_delim' => ' ',
    'title' => 'Indonesian rupiah',
    'name' => array(
        array('rupiah', 'rupiahs'),
    ),
    'frac_name' => array(
        array('sen', 'sens'),
    )
);