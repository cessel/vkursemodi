<?php

return array(
    'code' => 'PAB',
    'sign' => 'B/.',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Panamanian balboa',
    'name' => array(
        array('balboa', 'balboas'),
    ),
    'frac_name' => array(
        array('centesimo', 'centesimos'),
    )
);