<?php

return array(
    'code' => 'NGN',
    'sign' => '₦',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Nigerian naira',
    'name' => array(
        'naira',
    ),
    'frac_name' => array(
        'kobo',
    )
);