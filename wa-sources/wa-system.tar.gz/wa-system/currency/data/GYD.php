<?php

return array(
    'code' => 'GYD',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Guyanese dollar',
    'name' => array(
        array('dollar', 'dollars'),
        'G$',
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);