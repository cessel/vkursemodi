<?php

class waAnalyticsConfig 
{
    public function getEntities()
    {
        return array();
    }


}