<?php

return array(
    'view' => array('waSmarty3View'),
);
